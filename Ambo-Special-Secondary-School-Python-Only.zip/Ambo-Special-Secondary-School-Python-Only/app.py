from flask import Flask, request, redirect, url_for
from html import escape

app = Flask(__name__)

SCHOOL = "Ambo University Special Secondary School"

PROGRAMS = [
    ("🔬", "Natural Sciences", "Mathematics, Physics, Chemistry, Biology and scientific learning."),
    ("💻", "Computer Science", "Programming, computer skills, digital literacy and technology."),
    ("📚", "Academic Excellence", "Strong study habits, critical thinking and preparation for higher education."),
    ("🏆", "Science Competitions", "Research, innovation and student projects.")
]

ACTIVITIES = [
    ("🔬", "Science & Technology", "Research projects, innovation and technology activities."),
    ("🏆", "Academic Competitions", "Competitions that develop problem solving and creativity."),
    ("👥", "Student Leadership", "Leadership, teamwork and communication development."),
    ("🤝", "Community Service", "Activities that encourage responsibility and service.")
]

ANNOUNCEMENTS = [
    ("Welcome", "Welcome to the official school information website."),
    ("Academic Activities", "Academic, science and technology activities can be announced here."),
    ("Student Opportunities", "Scholarships, competitions and educational opportunities can be shared here.")
]

def page(title, content):
    return f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>{escape(title)} | {escape(SCHOOL)}</title>
<style>
*{{box-sizing:border-box}}
body{{margin:0;font-family:Arial,sans-serif;background:#f4f7fb;color:#172033;line-height:1.6}}
nav{{background:#0756a5;color:white;padding:15px 5%;position:sticky;top:0;z-index:10}}
.nav{{max-width:1100px;margin:auto;display:flex;justify-content:space-between;align-items:center;gap:20px}}
.logo{{color:white;text-decoration:none;font-size:21px;font-weight:bold}}
.logo span{{display:block;font-size:11px;font-weight:normal}}
.links{{display:flex;gap:15px;flex-wrap:wrap;justify-content:center}}
.links a{{color:white;text-decoration:none;font-weight:bold}}
.links a:hover{{color:#ffd166}}
.hero{{padding:80px 20px;text-align:center;background:linear-gradient(135deg,#e8f2ff,#ffffff)}}
.hero h1{{font-size:clamp(34px,6vw,60px);color:#0756a5;line-height:1.1}}
.hero p{{max-width:800px;margin:20px auto;font-size:19px;color:#4b5563}}
.btn{{display:inline-block;padding:12px 20px;border-radius:8px;text-decoration:none;font-weight:bold;margin:5px}}
.primary{{background:#0756a5;color:white}}
.secondary{{background:#e6eef8;color:#0756a5}}
.container{{max-width:1050px;margin:auto;padding:50px 20px}}
.title{{text-align:center;color:#0756a5;font-size:38px;margin-bottom:35px}}
.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:20px}}
.card{{background:white;padding:25px;border-radius:14px;box-shadow:0 5px 20px #0001}}
.card h3{{color:#0756a5}}
.icon{{font-size:40px}}
.section{{background:white;padding:25px;margin:20px 0;border-radius:12px}}
.notice{{background:white;padding:20px;margin:15px 0;border-left:5px solid #0756a5}}
form{{max-width:650px;margin:auto;background:white;padding:25px;border-radius:14px;box-shadow:0 5px 20px #0001}}
label{{display:block;font-weight:bold;margin:14px 0 5px}}
input,textarea{{width:100%;padding:13px;border:1px solid #ccd5e0;border-radius:7px;font-size:16px}}
textarea{{min-height:150px}}
button{{border:0;cursor:pointer;font-size:16px}}
footer{{background:#10243e;color:white;text-align:center;padding:30px 15px;margin-top:30px}}
.message{{max-width:650px;margin:20px auto;padding:14px;background:#dff5e4;color:#176b2b;border-radius:8px;text-align:center}}
@media(max-width:700px){{.nav{{flex-direction:column}}.links{{font-size:13px;gap:9px}}}}
</style>
</head>
<body>
<nav><div class="nav">
<a class="logo" href="/">AUSSSS<span>{escape(SCHOOL)}</span></a>
<div class="links">
<a href="/">Home</a>
<a href="/about">About</a>
<a href="/programs">Programs</a>
<a href="/students">Students</a>
<a href="/announcements">News</a>
<a href="/contact">Contact</a>
</div>
</div></nav>
{content}
<footer><b>{escape(SCHOOL)}</b><br>Knowledge • Discipline • Excellence<br>© 2026</footer>
</body>
</html>"""

def cards(items):
    return "".join(
        f'<div class="card"><div class="icon">{icon}</div><h3>{escape(title)}</h3><p>{escape(desc)}</p></div>'
        for icon, title, desc in items
    )

@app.route("/")
def home():
    content = f"""
<section class="hero">
<h1>{escape(SCHOOL)}</h1>
<p>A Python-powered website for school information, academic programs, student activities and communication.</p>
<a class="btn primary" href="/about">About Our School</a>
<a class="btn secondary" href="/programs">Academic Programs</a>
</section>
<div class="container">
<h2 class="title">Welcome</h2>
<div class="grid">
<div class="card"><div class="icon">📚</div><h3>Education</h3><p>Supporting academic excellence and lifelong learning.</p></div>
<div class="card"><div class="icon">🔬</div><h3>Innovation</h3><p>Encouraging scientific thinking, research and creativity.</p></div>
<div class="card"><div class="icon">👨‍🎓</div><h3>Students</h3><p>Highlighting student activities, leadership and achievements.</p></div>
<div class="card"><div class="icon">📢</div><h3>Announcements</h3><p>Sharing important school information and opportunities.</p></div>
</div></div>"""
    return page("Home", content)

@app.route("/about")
def about():
    content = """
<div class="container">
<h1 class="title">About Our School</h1>
<div class="section"><h2>Who We Are</h2>
<p>Ambo University Special Secondary School is an educational environment designed to help students develop strong academic, scientific, creative and leadership abilities.</p></div>
<div class="section"><h2>Mission</h2>
<p>To provide quality education and support students in developing knowledge, critical thinking, innovation, discipline and responsibility.</p></div>
<div class="section"><h2>Vision</h2>
<p>To develop competent, innovative and responsible young people who contribute positively to their communities and the wider world.</p></div>
<div class="section"><h2>Core Values</h2>
<p>Academic Excellence • Integrity • Discipline • Innovation • Leadership • Teamwork • Responsibility</p></div>
</div>"""
    return page("About", content)

@app.route("/programs")
def programs():
    content = f'<div class="container"><h1 class="title">Academic Programs</h1><div class="grid">{cards(PROGRAMS)}</div></div>'
    return page("Programs", content)

@app.route("/students")
def students():
    content = f'<div class="container"><h1 class="title">Student Activities</h1><div class="grid">{cards(ACTIVITIES)}</div></div>'
    return page("Students", content)

@app.route("/announcements")
def announcements():
    items = "".join(
        f'<div class="notice"><h3>{escape(title)}</h3><p>{escape(text)}</p></div>'
        for title, text in ANNOUNCEMENTS
    )
    return page("Announcements", f'<div class="container"><h1 class="title">Announcements</h1>{items}</div>')

@app.route("/contact", methods=["GET", "POST"])
def contact():
    message = ""
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip()
        text = request.form.get("message", "").strip()
        if name and email and text:
            print(f"CONTACT: {name} | {email} | {text}")
            message = '<div class="message">Your message was received successfully.</div>'
        else:
            message = '<div class="message">Please complete all fields.</div>'
    content = f"""
<div class="container">
<h1 class="title">Contact Us</h1>{message}
<form method="post">
<label>Name</label><input name="name" required placeholder="Your name">
<label>Email</label><input type="email" name="email" required placeholder="your@email.com">
<label>Message</label><textarea name="message" required placeholder="Write your message..."></textarea>
<button class="btn primary" type="submit">Send Message</button>
</form>
</div>"""
    return page("Contact", content)

@app.errorhandler(404)
def not_found(error):
    return page("404", '<div class="container" style="text-align:center"><h1 class="title">404</h1><p>Page not found.</p><a class="btn primary" href="/">Go Home</a></div>'), 404

if __name__ == "__main__":
    print("School website running at http://127.0.0.1:5000")
    app.run(host="0.0.0.0", port=5000, debug=True)
