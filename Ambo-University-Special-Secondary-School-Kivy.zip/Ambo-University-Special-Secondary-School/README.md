# Ambo University Special Secondary School

A mobile-friendly school application developed entirely with Python and Kivy.

## Features

- Home page
- About school
- Academic programs
- Student activities
- Announcements
- Contact form
- Mobile-friendly Kivy interface
- Offline starter version

## Project

```text
Ambo-University-Special-Secondary-School/
├── main.py
├── requirements.txt
└── README.md
```

## Install

```bash
pip install -r requirements.txt
```

## Run

```bash
python main.py
```

## Android

This project can later be packaged as an Android APK using Buildozer.

## Important

The school-specific history, official motto, contact details, programs and announcements should be replaced with verified official information before public release.
