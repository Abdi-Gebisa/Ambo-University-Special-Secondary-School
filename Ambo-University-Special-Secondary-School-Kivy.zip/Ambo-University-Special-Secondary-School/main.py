from kivy.app import App
from kivy.lang import Builder
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.core.window import Window

KV = """
#:import dp kivy.metrics.dp

<MainButton@Button>:
    size_hint_y: None
    height: dp(52)
    background_normal: ""
    background_color: 0.05, 0.28, 0.63, 1
    color: 1, 1, 1, 1
    font_size: dp(17)
    bold: True

<TitleLabel@Label>:
    color: 0.05, 0.28, 0.63, 1
    font_size: dp(28)
    bold: True
    halign: "center"
    valign: "middle"
    text_size: self.size

<SectionTitle@Label>:
    color: 0.05, 0.28, 0.63, 1
    font_size: dp(21)
    bold: True
    halign: "left"
    valign: "middle"
    text_size: self.size

<BodyLabel@Label>:
    color: 0.15, 0.18, 0.20, 1
    font_size: dp(16)
    halign: "left"
    valign: "top"
    text_size: self.width, None

<InfoCard@BoxLayout>:
    orientation: "vertical"
    padding: dp(18)
    spacing: dp(8)
    size_hint_y: None
    height: dp(150)
    canvas.before:
        Color:
            rgba: 1, 1, 1, 1
        RoundedRectangle:
            pos: self.pos
            size: self.size
            radius: [dp(12), dp(12), dp(12), dp(12)]

ScreenManager:
    HomeScreen:
    AboutScreen:
    ProgramsScreen:
    StudentsScreen:
    AnnouncementsScreen:
    ContactScreen:

<HomeScreen>:
    BoxLayout:
        orientation: "vertical"
        canvas.before:
            Color:
                rgba: 0.96, 0.97, 0.98, 1
            Rectangle:
                pos: self.pos
                size: self.size

        BoxLayout:
            size_hint_y: None
            height: dp(70)
            padding: dp(15)
            spacing: dp(10)
            canvas.before:
                Color:
                    rgba: 0.05, 0.28, 0.63, 1
                Rectangle:
                    pos: self.pos
                    size: self.size
            Label:
                text: "AUSSSS"
                color: 1, 1, 1, 1
                font_size: dp(26)
                bold: True
            Label:
                text: "Ambo University\\nSpecial Secondary School"
                color: 1, 1, 1, 1
                font_size: dp(13)
                halign: "right"
                valign: "middle"
                text_size: self.size

        ScrollView:
            GridLayout:
                cols: 1
                padding: dp(20)
                spacing: dp(15)
                size_hint_y: None
                height: self.minimum_height

                Label:
                    text: "🎓"
                    font_size: dp(60)
                    size_hint_y: None
                    height: dp(80)

                TitleLabel:
                    text: "Welcome to Ambo University\\nSpecial Secondary School"
                    size_hint_y: None
                    height: dp(100)

                Label:
                    text: "Knowledge • Discipline • Excellence"
                    color: 0.98, 0.65, 0.10, 1
                    font_size: dp(18)
                    bold: True
                    size_hint_y: None
                    height: dp(45)

                BodyLabel:
                    text: "A digital platform for learning, information, student activities and communication at Ambo University Special Secondary School."
                    halign: "center"
                    size_hint_y: None
                    height: dp(100)

                MainButton:
                    text: "About Our School"
                    on_release: root.manager.current = "about"

                MainButton:
                    text: "Academic Programs"
                    on_release: root.manager.current = "programs"

                MainButton:
                    text: "Student Activities"
                    on_release: root.manager.current = "students"

                MainButton:
                    text: "Announcements"
                    on_release: root.manager.current = "announcements"

                MainButton:
                    text: "Contact School"
                    on_release: root.manager.current = "contact"

<AboutScreen>:
    BoxLayout:
        orientation: "vertical"
        canvas.before:
            Color:
                rgba: 0.96, 0.97, 0.98, 1
            Rectangle:
                pos: self.pos
                size: self.size

        BoxLayout:
            size_hint_y: None
            height: dp(65)
            padding: dp(15)
            canvas.before:
                Color:
                    rgba: 0.05, 0.28, 0.63, 1
                Rectangle:
                    pos: self.pos
                    size: self.size
            Button:
                text: "←"
                size_hint_x: None
                width: dp(50)
                font_size: dp(30)
                background_normal: ""
                background_color: 0, 0, 0, 0
                color: 1, 1, 1, 1
                on_release: root.manager.current = "home"
            Label:
                text: "About Our School"
                color: 1, 1, 1, 1
                font_size: dp(22)
                bold: True

        ScrollView:
            GridLayout:
                cols: 1
                padding: dp(20)
                spacing: dp(18)
                size_hint_y: None
                height: self.minimum_height

                TitleLabel:
                    text: "Ambo University Special Secondary School"
                    size_hint_y: None
                    height: dp(100)

                SectionTitle:
                    text: "Who We Are"
                    size_hint_y: None
                    height: dp(40)

                BodyLabel:
                    text: "Ambo University Special Secondary School is dedicated to providing quality education and creating an environment where talented students can develop their academic, scientific, leadership and creative abilities."
                    size_hint_y: None
                    height: dp(150)

                SectionTitle:
                    text: "Our Mission"
                    size_hint_y: None
                    height: dp(40)

                BodyLabel:
                    text: "Our mission is to support students through quality education, discipline, innovation, critical thinking and preparation for higher education and future careers."
                    size_hint_y: None
                    height: dp(150)

                SectionTitle:
                    text: "Our Vision"
                    size_hint_y: None
                    height: dp(40)

                BodyLabel:
                    text: "Our vision is to develop competent, innovative, responsible and successful young people who can contribute positively to society."
                    size_hint_y: None
                    height: dp(130)

                SectionTitle:
                    text: "Our Values"
                    size_hint_y: None
                    height: dp(40)

                BodyLabel:
                    text: "✓ Academic Excellence\\n✓ Discipline\\n✓ Integrity\\n✓ Innovation\\n✓ Leadership\\n✓ Teamwork\\n✓ Responsibility"
                    size_hint_y: None
                    height: dp(180)

<ProgramsScreen>:
    BoxLayout:
        orientation: "vertical"
        canvas.before:
            Color:
                rgba: 0.96, 0.97, 0.98, 1
            Rectangle:
                pos: self.pos
                size: self.size

        BoxLayout:
            size_hint_y: None
            height: dp(65)
            padding: dp(15)
            canvas.before:
                Color:
                    rgba: 0.05, 0.28, 0.63, 1
                Rectangle:
                    pos: self.pos
                    size: self.size
            Button:
                text: "←"
                size_hint_x: None
                width: dp(50)
                font_size: dp(30)
                background_normal: ""
                background_color: 0, 0, 0, 0
                color: 1, 1, 1, 1
                on_release: root.manager.current = "home"
            Label:
                text: "Academic Programs"
                color: 1, 1, 1, 1
                font_size: dp(22)
                bold: True

        ScrollView:
            GridLayout:
                cols: 1
                padding: dp(20)
                spacing: dp(15)
                size_hint_y: None
                height: self.minimum_height

                TitleLabel:
                    text: "Academic Programs"
                    size_hint_y: None
                    height: dp(70)

                InfoCard:
                    Label:
                        text: "🔬 Natural Sciences"
                        font_size: dp(20)
                        bold: True
                        color: 0.05, 0.28, 0.63, 1
                    BodyLabel:
                        text: "Mathematics, Physics, Chemistry, Biology and other science-related subjects."

                InfoCard:
                    Label:
                        text: "📚 Social Sciences"
                        font_size: dp(20)
                        bold: True
                        color: 0.05, 0.28, 0.63, 1
                    BodyLabel:
                        text: "Subjects that help students understand society, history, geography, economics and related fields."

                InfoCard:
                    Label:
                        text: "🗣️ English Language"
                        font_size: dp(20)
                        bold: True
                        color: 0.05, 0.28, 0.63, 1
                    BodyLabel:
                        text: "Development of English reading, writing, speaking, listening and grammar skills."

                InfoCard:
                    Label:
                        text: "💻 Information Technology"
                        font_size: dp(20)
                        bold: True
                        color: 0.05, 0.28, 0.63, 1
                    BodyLabel:
                        text: "Computer literacy, digital skills, programming and technology-related learning."

<StudentsScreen>:
    BoxLayout:
        orientation: "vertical"
        canvas.before:
            Color:
                rgba: 0.96, 0.97, 0.98, 1
            Rectangle:
                pos: self.pos
                size: self.size

        BoxLayout:
            size_hint_y: None
            height: dp(65)
            padding: dp(15)
            canvas.before:
                Color:
                    rgba: 0.05, 0.28, 0.63, 1
                Rectangle:
                    pos: self.pos
                    size: self.size
            Button:
                text: "←"
                size_hint_x: None
                width: dp(50)
                font_size: dp(30)
                background_normal: ""
                background_color: 0, 0, 0, 0
                color: 1, 1, 1, 1
                on_release: root.manager.current = "home"
            Label:
                text: "Student Life"
                color: 1, 1, 1, 1
                font_size: dp(22)
                bold: True

        ScrollView:
            GridLayout:
                cols: 1
                padding: dp(20)
                spacing: dp(15)
                size_hint_y: None
                height: self.minimum_height

                TitleLabel:
                    text: "Student Activities"
                    size_hint_y: None
                    height: dp(70)

                InfoCard:
                    Label:
                        text: "🔬 Science & Technology"
                        font_size: dp(20)
                        bold: True
                        color: 0.05, 0.28, 0.63, 1
                    BodyLabel:
                        text: "Students can participate in scientific research, technology projects and innovation activities."

                InfoCard:
                    Label:
                        text: "🏆 Academic Competitions"
                        font_size: dp(20)
                        bold: True
                        color: 0.05, 0.28, 0.63, 1
                    BodyLabel:
                        text: "Academic competitions encourage students to improve their knowledge and problem-solving skills."

                InfoCard:
                    Label:
                        text: "👥 Leadership"
                        font_size: dp(20)
                        bold: True
                        color: 0.05, 0.28, 0.63, 1
                    BodyLabel:
                        text: "Students develop leadership, teamwork, communication and decision-making skills."

                InfoCard:
                    Label:
                        text: "🤝 Community Service"
                        font_size: dp(20)
                        bold: True
                        color: 0.05, 0.28, 0.63, 1
                    BodyLabel:
                        text: "Students are encouraged to participate in activities that support their school and community."

<AnnouncementsScreen>:
    BoxLayout:
        orientation: "vertical"
        canvas.before:
            Color:
                rgba: 0.96, 0.97, 0.98, 1
            Rectangle:
                pos: self.pos
                size: self.size

        BoxLayout:
            size_hint_y: None
            height: dp(65)
            padding: dp(15)
            canvas.before:
                Color:
                    rgba: 0.05, 0.28, 0.63, 1
                Rectangle:
                    pos: self.pos
                    size: self.size
            Button:
                text: "←"
                size_hint_x: None
                width: dp(50)
                font_size: dp(30)
                background_normal: ""
                background_color: 0, 0, 0, 0
                color: 1, 1, 1, 1
                on_release: root.manager.current = "home"
            Label:
                text: "Announcements"
                color: 1, 1, 1, 1
                font_size: dp(22)
                bold: True

        ScrollView:
            GridLayout:
                cols: 1
                padding: dp(20)
                spacing: dp(15)
                size_hint_y: None
                height: self.minimum_height

                TitleLabel:
                    text: "School Announcements"
                    size_hint_y: None
                    height: dp(70)

                InfoCard:
                    Label:
                        text: "📢 School Information"
                        font_size: dp(20)
                        bold: True
                        color: 0.05, 0.28, 0.63, 1
                    BodyLabel:
                        text: "Important school announcements can be displayed here."

                InfoCard:
                    Label:
                        text: "📅 Academic Calendar"
                        font_size: dp(20)
                        bold: True
                        color: 0.05, 0.28, 0.63, 1
                    BodyLabel:
                        text: "Academic dates, examinations and other important events can be added here."

                InfoCard:
                    Label:
                        text: "🎓 Student Opportunities"
                        font_size: dp(20)
                        bold: True
                        color: 0.05, 0.28, 0.63, 1
                    BodyLabel:
                        text: "Scholarships, competitions, science fairs and other student opportunities can be announced here."

<ContactScreen>:
    BoxLayout:
        orientation: "vertical"
        canvas.before:
            Color:
                rgba: 0.96, 0.97, 0.98, 1
            Rectangle:
                pos: self.pos
                size: self.size

        BoxLayout:
            size_hint_y: None
            height: dp(65)
            padding: dp(15)
            canvas.before:
                Color:
                    rgba: 0.05, 0.28, 0.63, 1
                Rectangle:
                    pos: self.pos
                    size: self.size
            Button:
                text: "←"
                size_hint_x: None
                width: dp(50)
                font_size: dp(30)
                background_normal: ""
                background_color: 0, 0, 0, 0
                color: 1, 1, 1, 1
                on_release: root.manager.current = "home"
            Label:
                text: "Contact Us"
                color: 1, 1, 1, 1
                font_size: dp(22)
                bold: True

        ScrollView:
            GridLayout:
                cols: 1
                padding: dp(20)
                spacing: dp(15)
                size_hint_y: None
                height: self.minimum_height

                TitleLabel:
                    text: "Contact Our School"
                    size_hint_y: None
                    height: dp(70)

                SectionTitle:
                    text: "📍 Location"
                    size_hint_y: None
                    height: dp(40)

                BodyLabel:
                    text: "Ambo, Ethiopia"
                    size_hint_y: None
                    height: dp(50)

                SectionTitle:
                    text: "🏫 School"
                    size_hint_y: None
                    height: dp(40)

                BodyLabel:
                    text: "Ambo University Special Secondary School"
                    size_hint_y: None
                    height: dp(70)

                SectionTitle:
                    text: "✉️ Send a Message"
                    size_hint_y: None
                    height: dp(40)

                TextInput:
                    id: name_input
                    hint_text: "Your Name"
                    multiline: False
                    size_hint_y: None
                    height: dp(50)

                TextInput:
                    id: email_input
                    hint_text: "Your Email"
                    multiline: False
                    size_hint_y: None
                    height: dp(50)

                TextInput:
                    id: message_input
                    hint_text: "Your Message"
                    multiline: True
                    size_hint_y: None
                    height: dp(130)

                MainButton:
                    text: "Send Message"
                    on_release: root.send_message()

                Label:
                    id: status_label
                    text: ""
                    color: 0.18, 0.49, 0.20, 1
                    font_size: dp(16)
                    halign: "center"
                    text_size: self.size
                    size_hint_y: None
                    height: dp(60)
"""

class HomeScreen(Screen):
    pass

class AboutScreen(Screen):
    pass

class ProgramsScreen(Screen):
    pass

class StudentsScreen(Screen):
    pass

class AnnouncementsScreen(Screen):
    pass

class ContactScreen(Screen):
    def send_message(self):
        name = self.ids.name_input.text.strip()
        email = self.ids.email_input.text.strip()
        message = self.ids.message_input.text.strip()

        if not name or not email or not message:
            self.ids.status_label.color = (0.8, 0.1, 0.1, 1)
            self.ids.status_label.text = "Please fill in all fields."
            return

        self.ids.status_label.color = (0.18, 0.49, 0.20, 1)
        self.ids.status_label.text = "Thank you! Your message has been prepared."

        self.ids.name_input.text = ""
        self.ids.email_input.text = ""
        self.ids.message_input.text = ""

class SchoolApp(App):
    title = "Ambo University Special Secondary School"

    def build(self):
        Builder.load_string(KV)
        return ScreenManager()

if __name__ == "__main__":
    SchoolApp().run()
